async function attachEvents() {

  const baseUrl = "http://localhost:3030/jsonstore/collections/students";
  const [firstName, secondName, facNumber, grade] = document.getElementsByTagName("input");
  const buttonSubmit = document.getElementById("submit");
  const table = document.querySelector("table tbody");

  const responce = await fetch(baseUrl);
  const studentData = await responce.json();

  for (const infos of Object.values(studentData)) {
    const row = document.createElement("tr");
    const tdName = document.createElement("td");
    const tdSecondName = document.createElement("td");
    const tdFacNum = document.createElement("td");
    const tdGrade = document.createElement("td");

    tdName.textContent = infos.firstName;
    tdSecondName.textContent = infos.lastName;
    tdFacNum.textContent = infos.facultyNumber;
    tdGrade.textContent = infos.grade;

    row.appendChild(tdName);
    row.appendChild(tdSecondName);
    row.appendChild(tdFacNum);
    row.appendChild(tdGrade);

    table.appendChild(row);
  }
  
  buttonSubmit.addEventListener("click", async () => {

    const isValidInput =
      firstName.value !== "" &&
      secondName.value !== "" &&
      facNumber.value !== "" &&
      grade.value !== "";

    if (isValidInput) {

      const student = {
        firstName: firstName.value,
        lastName: secondName.value,
        facultyNumber: facNumber.value,
        grade: grade.value,
      };

      await fetch(baseUrl, {
        method: "POST",
        body: JSON.stringify(student),
      });

      const newRow = document.createElement("tr");

      const rowName = document.createElement("td");
      const rowSecondName = document.createElement("td");
      const rowFacNum = document.createElement("td");
      const rowGrade = document.createElement("td");

      rowName.textContent = firstName.value;
      rowSecondName.textContent = secondName.value;
      rowFacNum.textContent = facNumber.value;
      rowGrade.textContent = grade.value;

      newRow.appendChild(rowName);
      newRow.appendChild(rowSecondName);
      newRow.appendChild(rowFacNum);
      newRow.appendChild(rowGrade);

      table.appendChild(newRow);

      firstName.value = "";
      secondName.value = "";
      facNumber.value = "";
      grade.value = "";
    }
    
  })
}

attachEvents();